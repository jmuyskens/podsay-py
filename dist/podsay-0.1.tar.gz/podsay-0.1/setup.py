from distutils.core import setup

setup(
	name='podsay',
	version='0.1',
	packages=['podsay',],
	license='GNU Lesser General Public License',
	long_description=open('README').read(),
)